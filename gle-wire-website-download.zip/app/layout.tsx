import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "G L E WIRE — Connect with your people",
  description: "Private family and friends chat membership",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
