"use client";
import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { Suspense } from "react";
import { browserSupabase } from "@/lib/supabase";

function CallbackContent() {
  const params = useSearchParams();
  const [status, setStatus] = useState("Checking payment with the server…");
  useEffect(() => {
    const reference = params.get("reference");
    if (!reference) { setStatus("No payment reference was supplied. Log in and check your subscription."); return; }
    async function verify() {
      const supabase = browserSupabase();
      const { data: sessionData } = await supabase.auth.getSession();
      const accessToken = sessionData.session?.access_token;
      if (!accessToken) { setStatus("Log in with the account used to pay, then open this page again."); return; }
      const r = await fetch("/api/paystack/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json", "Authorization": `Bearer ${accessToken}` },
        body: JSON.stringify({ reference })
      });
      return r;
    }
    verify().then(async r => {
      if (!r) return;
      const data = await r.json();
      setStatus(r.ok && data.active ? "Payment verified. Your membership is active. Return to the home page and log in again if needed." : (data.error || "Payment is not confirmed yet. Please wait and refresh."));
    }).catch(() => setStatus("Could not verify payment right now. Please refresh in a moment."));
  }, [params]);
  return <main className="shell"><div className="panel"><h1>Payment status</h1><p>{status}</p><a href="/">Return to G L E WIRE</a></div></main>;
}
export default function PaymentCallback() {
  return <Suspense fallback={<main className="shell"><div className="panel">Checking payment…</div></main>}><CallbackContent/></Suspense>;
}
