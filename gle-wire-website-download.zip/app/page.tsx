"use client";

import { useEffect, useState } from "react";
import { browserSupabase } from "@/lib/supabase";
import type { User } from "@supabase/supabase-js";

type Msg = { id: number; sender_id: string; body: string; created_at: string };
const PRICE_NAIRA = 3000;

export default function Home() {
  const [user, setUser] = useState<User | null>(null);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const [messages, setMessages] = useState<Msg[]>([]);
  const [status, setStatus] = useState("Create an account or log in to begin.");
  const [loading, setLoading] = useState(false);
  const [active, setActive] = useState(false);
  const [draft, setDraft] = useState("");
  const [recipient, setRecipient] = useState("");
  const [referral, setReferral] = useState<{code:string;link:string;referrals:number;earnedNaira:number;pendingNaira:number}|null>(null);
  const [referralInput, setReferralInput] = useState("");
  const [referralStatus, setReferralStatus] = useState("");

  const supabase = browserSupabase();

  async function refreshSession() {
    if (typeof window !== "undefined") {
      const incomingRef = new URLSearchParams(window.location.search).get("ref");
      if (incomingRef && /^[a-zA-Z0-9]{6,20}$/.test(incomingRef)) {
        setReferralCode(incomingRef);
        try { window.sessionStorage.setItem("glewire_referral_code", incomingRef); } catch {}
      } else {
        try { setReferralCode(window.sessionStorage.getItem("glewire_referral_code") || ""); } catch {}
      }
    }
    const { data } = await supabase.auth.getUser();
    setUser(data.user);
    if (data.user) {
      await refreshSubscription(data.user.id);
      await refreshReferralDashboard(data.user.id);
    }
  }

  async function refreshReferralDashboard(userId: string) {
    const [{ data: profile }, { data: rewards }, { data: payouts }] = await Promise.all([
      supabase.from("profiles").select("referral_code").eq("id", userId).maybeSingle(),
      supabase.from("referral_rewards").select("amount_kobo, referred_user_id").eq("referrer_id", userId),
      supabase.from("referral_payout_requests").select("id,amount_kobo,status,created_at").eq("user_id", userId).order("created_at", { ascending: false }).limit(20)
    ]);
    setMyReferralCode(profile?.referral_code || "");
    setReferralCount(rewards?.length || 0);
    setReferralEarnings((rewards || []).reduce((sum: number, row: {amount_kobo:number}) => sum + row.amount_kobo, 0));
    setPayoutRows((payouts || []) as {id:string;amount_kobo:number;status:string;created_at:string}[]);
    setWithdrawnOrReserved((payouts || []).filter((row: {status:string;amount_kobo:number}) => ["pending","approved","paid"].includes(row.status)).reduce((sum:number,row:{amount_kobo:number})=>sum+row.amount_kobo,0));
  }

  const availableReferralBalance = Math.max(0, referralEarnings - withdrawnOrReserved);
  async function loadReferralDashboard() {
    const { data: sessionData } = await supabase.auth.getSession();
    const token = sessionData.session?.access_token;
    if (!token) return;
    const res = await fetch("/api/referrals/me", { headers: { Authorization: `Bearer ${token}` } });
    const data = await res.json();
    if (res.ok) setReferral(data);
  }

  async function applyReferral() {
    const { data: sessionData } = await supabase.auth.getSession();
    const token = sessionData.session?.access_token;
    if (!token || !referralInput.trim()) return;
    const res = await fetch("/api/referrals/attribute", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      body: JSON.stringify({ code: referralInput.trim() })
    });
    const data = await res.json();
    setReferralStatus(res.ok ? "Referral saved." : (data.error || "Could not save referral."));
  }

  async function refreshSubscription(userId: string) {
    const { data, error } = await supabase.from("subscriptions").select("current_period_end,status")
      .eq("user_id", userId).eq("status", "active").gt("current_period_end", new Date().toISOString())
      .order("current_period_end", { ascending: false }).limit(1);
    setActive(!error && !!data?.length);
  }
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const incoming = params.get("ref");
    if (incoming) {
      sessionStorage.setItem("glewire_referral_code", incoming.toUpperCase());
      setReferralInput(incoming.toUpperCase());
    } else {
      setReferralInput(sessionStorage.getItem("glewire_referral_code") || "");
    }
    refreshSession();
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
      if (session?.user) { refreshSubscription(session.user.id); loadReferralDashboard(); }
      else { setActive(false); setMessages([]); setReferral(null); }
    });
    return () => listener.subscription.unsubscribe();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function auth(mode: "signup" | "login") {
    setLoading(true); setStatus("");
    const result = mode === "signup"
      ? await supabase.auth.signUp({
          email, password,
          options: { data: { referral_code: referralCode || null } }
        })
      : await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (result.error) setStatus(result.error.message);
    else if (result.data.user && referralInput.trim()) {
      const { data: sessionData } = await supabase.auth.getSession();
      if (sessionData.session?.access_token) {
        await fetch("/api/referrals/attribute", { method: "POST", headers: {
          "Content-Type": "application/json", Authorization: `Bearer ${sessionData.session.access_token}`
        }, body: JSON.stringify({ code: referralInput.trim() }) });
      }
      if (mode === "signup" && !result.data.session) setStatus("Check your email to confirm your account. Your referral will be saved after you log in.");
      else setStatus(mode === "signup" ? "Account created." : "Logged in.");
    } else if (mode === "signup" && !result.data.session) setStatus("Check your email to confirm your account, then log in.");
    else setStatus(mode === "signup" ? "Account created." : "Logged in.");
    if (result.data.user) loadReferralDashboard();
  }

  async function requestPayout() {
    if (!user) return;
    setLoading(true); setStatus("Submitting payout request…");
    const { data, error } = await supabase.rpc("request_referral_payout");
    setLoading(false);
    if (error) setStatus(error.message);
    else {
      setStatus("Payout request submitted for admin review. It is not paid automatically.");
      await refreshReferralDashboard(user.id);
    }
  }

  async function copyReferralLink() {
    if (!myReferralCode) return;
    const link = `${window.location.origin}/?ref=${myReferralCode}`;
    try {
      await navigator.clipboard.writeText(link);
      setStatus("Referral link copied. Share it with family and friends.");
    } catch {
      setStatus(link);
    }
  }

  async function subscribe() {
    if (!user) return;
    setLoading(true); setStatus("Opening secure Paystack checkout…");
    try {
      const { data: sessionData } = await supabase.auth.getSession();
      const accessToken = sessionData.session?.access_token;
      if (!accessToken) throw new Error("Your session expired. Please log in again.");
      const res = await fetch("/api/paystack/initialize", {
        method: "POST",
        headers: { "Authorization": `Bearer ${accessToken}` }
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Could not start checkout");
      window.location.href = data.authorization_url;
    } catch (e) {
      setStatus(e instanceof Error ? e.message : "Checkout failed.");
      setLoading(false);
    }
  }

  async function loadMessages() {
    if (!user || !active) return;
    const { data, error } = await supabase.from("messages").select("id,sender_id,body,created_at")
      .order("created_at", { ascending: true }).limit(100);
    if (error) setStatus("Could not load chat. Check your database SQL and membership.");
    else setMessages((data ?? []) as Msg[]);
  }
  useEffect(() => { loadMessages(); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [user?.id, active]);

  async function sendMessage() {
    if (!user || !active || !draft.trim() || !recipient.trim()) {
      setStatus("Enter the recipient's registered email and a message.");
      return;
    }
    setLoading(true);
    const { data: person, error: personError } = await supabase.from("profiles").select("id")
      .eq("email", recipient.trim().toLowerCase()).maybeSingle();
    if (personError || !person) {
      setStatus("Recipient not found. They may need to register first.");
      setLoading(false); return;
    }
    if (person.id === user.id) {
      setStatus("Choose a different person to message."); setLoading(false); return;
    }
    const { data: conv, error: convError } = await supabase.rpc("get_or_create_direct_conversation", { other_user_id: person.id });
    if (convError || !conv) {
      setStatus("Could not open private conversation. Check the SQL setup.");
      setLoading(false); return;
    }
    const { error } = await supabase.from("messages").insert({ conversation_id: conv, sender_id: user.id, body: draft.trim() });
    setLoading(false);
    if (error) setStatus("Message failed: " + error.message);
    else { setDraft(""); setStatus("Message sent."); await loadMessages(); }
  }

  return <main className="shell">
    <header className="top">
      <div className="logo">G</div>
      <div><strong style={{fontSize:21}}>G L E WIRE</strong><div className="muted small">Your people. Your conversations.</div></div>
    </header>
    <section className="panel">
      <div className="muted small">PRIVATE FAMILY & FRIENDS CHAT</div>
      <h1>Stay close to your people.</h1>
      <p className="muted">Create an account, subscribe for ₦3,000 per month, and chat privately with people you know.</p>
      <div className="notice"><strong>Membership: ₦3,000 / 30 days</strong><br/><span className="small">Chat unlocks only after the server verifies a successful payment.</span></div>
    </section>

    {!user ? <section className="panel stack">
      <h2>Create account or log in</h2>
      <label className="small">Email address<input type="email" autoComplete="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com"/></label>
      <label className="small">Password (at least 8 characters)<input type="password" autoComplete="current-password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Choose a strong password"/></label>
      <label className="small">Referral code (optional)<input value={referralInput} onChange={e=>setReferralInput(e.target.value.toUpperCase())} placeholder="Enter a friend's code"/></label>
      <div className="row">
        <button disabled={loading || !email || password.length < 8} onClick={()=>auth("signup")}>Create account</button>
        <button disabled={loading || !email || password.length < 8} onClick={()=>auth("login")}>Log in</button>
      </div>
      <p className="muted small">If email confirmation is enabled, confirm your email before logging in.</p>
    </section> : <>
      <section className="panel stack">
        <div className="row"><div><strong>Signed in</strong><div className="muted small">{user.email}</div></div><button onClick={async()=>{await supabase.auth.signOut();setStatus("Logged out.");}}>Log out</button></div>
        <div className="notice">
          <strong>Invite family and friends</strong>
          <p className="small">Share your personal link. Referral rewards are only payable after the referred person completes a verified paid subscription and the reward is approved under the program rules.</p>
          {referral ? <>
            <input readOnly value={referral.link} aria-label="Your referral link" />
            <div className="row" style={{marginTop:8}}>
              <button onClick={async()=>{await navigator.clipboard.writeText(referral.link);setReferralStatus("Referral link copied.");}}>Copy invite link</button>
              <button onClick={()=>{window.open("https://wa.me/?text="+encodeURIComponent("Join me on G L E WIRE: "+referral.link)," _blank");}}>Share on WhatsApp</button>
            </div>
            <div className="small" style={{marginTop:10}}>Invited accounts: {referral.referrals} · Approved/paid rewards: ₦{referral.earnedNaira.toLocaleString()} · Pending: ₦{referral.pendingNaira.toLocaleString()}</div>
          </> : <button onClick={loadReferralDashboard}>Load my invite link</button>}
          {referralStatus && <div className="small">{referralStatus}</div>}
        </div>
        {!referral && referralInput && <div className="panel stack"><label className="small">Referral code<input value={referralInput} onChange={e=>setReferralInput(e.target.value)} placeholder="Optional referral code"/></label><button onClick={applyReferral}>Apply referral code</button></div>}
        {active ? <div className="notice">Subscription active. Chat is unlocked.</div> :
          <><div className="notice">Your subscription is not active yet. Subscribe to unlock chat.</div><button disabled={loading} onClick={subscribe}>Pay ₦3,000 with Paystack</button></>}
      </section>
      <section className="panel stack">
        <h2>Invite & earn</h2>
        <p className="muted small">Earn ₦300 when a genuine new member joins through your link and completes their first verified ₦3,000 subscription. No reward is paid for sign-ups alone.</p>
        <label className="small">Your referral link<input readOnly value={myReferralCode ? `${typeof window !== "undefined" ? window.location.origin : ""}/?ref=${myReferralCode}` : "Loading your referral link…"}/></label>
        <button disabled={!myReferralCode} onClick={copyReferralLink}>Copy referral link</button>
        <div className="row">
          <div className="notice"><strong>{referralCount}</strong><br/><span className="small">Qualified referrals</span></div>
          <div className="notice"><strong>₦{(referralEarnings/100).toLocaleString("en-NG")}</strong><br/><span className="small">Total earned</span></div>
        </div>
        <div className="notice"><strong>Available balance: ₦{(availableReferralBalance/100).toLocaleString("en-NG")}</strong><br/><span className="small">Minimum cash withdrawal: ₦5,000. Requests require admin approval; payment is not automatic.</span></div>
        <button disabled={loading || availableReferralBalance < 500000} onClick={requestPayout}>Request cash withdrawal</button>
        <h3>Payout requests</h3>
        {payoutRows.length === 0 ? <p className="muted small">No payout requests yet.</p> : payoutRows.map(row=><div className="message" key={row.id}>₦{(row.amount_kobo/100).toLocaleString("en-NG")} · {row.status} · {new Date(row.created_at).toLocaleDateString()}</div>)}
      </section>
      {active && <section className="panel stack">
        <h2>Private chat</h2>
        <label className="small">Friend's registered email<input value={recipient} onChange={e=>setRecipient(e.target.value)} placeholder="friend@example.com"/></label>
        <label className="small">Message<textarea value={draft} onChange={e=>setDraft(e.target.value)} rows={3} maxLength={2000} placeholder="Write a message…"/></label>
        <button disabled={loading || !draft.trim() || !recipient.trim()} onClick={sendMessage}>Send private message</button>
        <p className="muted small">Messages are stored privately in the database. This starter displays the most recent messages from your account's permitted rows; add a conversation selector before public launch.</p>
        <button onClick={loadMessages}>Refresh messages</button>
        <div className="messages">{messages.map(m=><div className={"message "+(m.sender_id===user.id?"mine":"")} key={m.id}><div>{m.body}</div><div className="muted small">{m.sender_id===user.id?"You":"Friend"} · {new Date(m.created_at).toLocaleString()}</div></div>)}</div>
      </section>}
    </>}
    {status && <div role="status" className="notice">{status}</div>}
    <footer className="muted small">G L E WIRE · Never share your password or payment PIN. Use test payments until all checks pass.</footer>
  </main>;
}
