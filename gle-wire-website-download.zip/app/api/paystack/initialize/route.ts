import { NextResponse } from "next/server";
import { adminSupabase } from "@/lib/server-supabase";
import { createClient } from "@supabase/supabase-js";

export const runtime = "nodejs";

export async function POST(request: Request) {
  const authHeader = request.headers.get("authorization");
  const token = authHeader?.startsWith("Bearer ") ? authHeader.slice(7) : "";
  if (!token) return NextResponse.json({ error: "Please log in first." }, { status: 401 });

  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const anon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  const secret = process.env.PAYSTACK_SECRET_KEY;
  if (!url || !anon || !secret) return NextResponse.json({ error: "Server configuration is incomplete." }, { status: 500 });

  const userClient = createClient(url, anon, { global: { headers: { Authorization: `Bearer ${token}` } } });
  const { data: { user }, error: authError } = await userClient.auth.getUser(token);
  if (authError || !user?.email) return NextResponse.json({ error: "Invalid session." }, { status: 401 });

  const admin = adminSupabase();
  const { data: existing } = await admin.from("subscriptions").select("id")
    .eq("user_id", user.id).eq("status", "active").gt("current_period_end", new Date().toISOString()).limit(1);
  if (existing?.length) return NextResponse.json({ error: "Your subscription is already active." }, { status: 409 });

  const reference = `glewire_${user.id.replaceAll("-", "").slice(0, 16)}_${crypto.randomUUID().replaceAll("-", "")}`;
  const baseUrl = process.env.NEXT_PUBLIC_SITE_URL;
  if (!baseUrl) return NextResponse.json({ error: "Set NEXT_PUBLIC_SITE_URL on the server." }, { status: 500 });

  const response = await fetch("https://api.paystack.co/transaction/initialize", {
    method: "POST",
    headers: { Authorization: `Bearer ${secret}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      email: user.email,
      amount: 300000,
      currency: "NGN",
      reference,
      callback_url: `${baseUrl}/payment/callback`,
      metadata: { user_id: user.id, product: "glewire_monthly_membership" }
    }),
    cache: "no-store"
  });
  const result = await response.json();
  if (!response.ok || !result.status || !result.data?.authorization_url) {
    return NextResponse.json({ error: "Paystack could not initialize payment." }, { status: 502 });
  }
  return NextResponse.json({ authorization_url: result.data.authorization_url, reference: result.data.reference });
}
