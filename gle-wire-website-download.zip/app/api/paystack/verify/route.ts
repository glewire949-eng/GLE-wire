import { NextResponse } from "next/server";
import { adminSupabase } from "@/lib/server-supabase";
import { createClient } from "@supabase/supabase-js";

export const runtime = "nodejs";

export async function POST(request: Request) {
  const { reference } = await request.json().catch(() => ({}));
  if (typeof reference !== "string" || !/^glewire_[a-zA-Z0-9_]+$/.test(reference)) {
    return NextResponse.json({ error: "Invalid reference." }, { status: 400 });
  }
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const anon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  const secret = process.env.PAYSTACK_SECRET_KEY;
  if (!url || !anon || !secret) return NextResponse.json({ error: "Server configuration is incomplete." }, { status: 500 });

  // Require an authenticated user and only allow them to verify their own reference.
  const authHeader = request.headers.get("authorization");
  const token = authHeader?.startsWith("Bearer ") ? authHeader.slice(7) : "";
  // The callback can be opened after a redirect, so the browser sends its current session below.
  if (!token) return NextResponse.json({ error: "Log in to verify this payment, then return to this page." }, { status: 401 });
  const userClient = createClient(url, anon, { global: { headers: { Authorization: `Bearer ${token}` } } });
  const { data: { user }, error: authError } = await userClient.auth.getUser(token);
  if (authError || !user) return NextResponse.json({ error: "Please log in again to verify payment." }, { status: 401 });
  const expectedPrefix = `glewire_${user.id.replaceAll("-", "").slice(0, 16)}_`;
  if (!reference.startsWith(expectedPrefix)) return NextResponse.json({ error: "This payment reference does not belong to your account." }, { status: 403 });

  const response = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`, {
    headers: { Authorization: `Bearer ${secret}` }, cache: "no-store"
  });
  const result = await response.json();
  const tx = result?.data;
  if (!response.ok || !result.status || tx?.status !== "success" || tx?.amount !== 300000 || tx?.currency !== "NGN" || tx?.metadata?.user_id !== user.id) {
    return NextResponse.json({ error: "Payment is not verified. No membership was activated." }, { status: 402 });
  }

  const admin = adminSupabase();
  const { data: prior } = await admin.from("payment_events").select("reference").eq("reference", reference).maybeSingle();
  if (!prior) {
    const start = new Date();
    const end = new Date(start.getTime() + 30 * 24 * 60 * 60 * 1000);
    const { error: insertError } = await admin.from("payment_events").insert({
      reference, user_id: user.id, amount_kobo: 300000, currency: "NGN", status: "success"
    });
    if (insertError) {
      // Concurrent webhook/verify requests may race; continue only if the event now exists.
      const { data: raced } = await admin.from("payment_events").select("reference").eq("reference", reference).maybeSingle();
      if (!raced) return NextResponse.json({ error: "Could not record payment. Contact support before paying again." }, { status: 500 });
    } else {
      const { error: subError } = await admin.from("subscriptions").upsert({
        user_id: user.id, status: "active", current_period_start: start.toISOString(),
        current_period_end: end.toISOString(), last_payment_reference: reference
      }, { onConflict: "user_id" });
      if (subError) return NextResponse.json({ error: "Payment verified but membership update failed. Contact support." }, { status: 500 });
    }
  }
  // Reward the referring member only after the verified payment has been recorded.
  // The database enforces one reward per referred user and one per payment reference.
  const { error: rewardError } = await admin.rpc("award_referral_reward", {
    p_referred_user_id: user.id,
    p_payment_reference: reference,
    p_amount_kobo: 300000
  });
  if (rewardError) {
    console.error("Referral reward processing failed", rewardError.message);
    // Do not undo an otherwise verified membership; the webhook can retry later.
  }
  return NextResponse.json({ active: true });
}
