import { NextResponse } from "next/server";
import { createHmac, timingSafeEqual } from "node:crypto";
import { adminSupabase } from "@/lib/server-supabase";

export const runtime = "nodejs";

export async function POST(request: Request) {
  const secret = process.env.PAYSTACK_SECRET_KEY;
  if (!secret) return NextResponse.json({ error: "Missing server key." }, { status: 500 });
  const raw = await request.text();
  const signature = request.headers.get("x-paystack-signature") || "";
  const expected = createHmac("sha512", secret).update(raw).digest("hex");
  const a = Buffer.from(signature, "utf8");
  const b = Buffer.from(expected, "utf8");
  if (a.length !== b.length || !timingSafeEqual(a, b)) return NextResponse.json({ error: "Invalid signature." }, { status: 401 });

  const event = JSON.parse(raw);
  if (event.event !== "charge.success") return NextResponse.json({ received: true });
  const tx = event.data;
  if (tx?.status !== "success" || tx?.amount !== 300000 || tx?.currency !== "NGN") {
    return NextResponse.json({ received: true });
  }
  const userId = tx?.metadata?.user_id;
  const reference = tx?.reference;
  if (typeof userId !== "string" || typeof reference !== "string") return NextResponse.json({ error: "Missing metadata." }, { status: 400 });

  // Verify directly with Paystack as well; never trust the webhook body alone for fulfillment.
  const verify = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`, {
    headers: { Authorization: `Bearer ${secret}` }, cache: "no-store"
  });
  const verified = await verify.json();
  if (!verify.ok || !verified.status || verified.data?.status !== "success" ||
      verified.data?.amount !== 300000 || verified.data?.currency !== "NGN" ||
      verified.data?.metadata?.user_id !== userId) {
    return NextResponse.json({ error: "Transaction verification failed." }, { status: 400 });
  }

  const admin = adminSupabase();
  const { data: prior } = await admin.from("payment_events").select("reference").eq("reference", reference).maybeSingle();
  if (!prior) {
    const { error: payErr } = await admin.from("payment_events").insert({
      reference, user_id: userId, amount_kobo: 300000, currency: "NGN", status: "success"
    });
    if (payErr) {
      const { data: raced } = await admin.from("payment_events").select("reference").eq("reference", reference).maybeSingle();
      if (!raced) return NextResponse.json({ error: "Could not record payment." }, { status: 500 });
      return NextResponse.json({ received: true });
    }
    const now = new Date();
    const { error: subErr } = await admin.from("subscriptions").upsert({
      user_id: userId, status: "active", current_period_start: now.toISOString(),
      current_period_end: new Date(now.getTime() + 30*24*60*60*1000).toISOString(),
      last_payment_reference: reference
    }, { onConflict: "user_id" });
    if (subErr) return NextResponse.json({ error: "Membership update failed." }, { status: 500 });
  }
  const { error: rewardError } = await admin.rpc("award_referral_reward", {
    p_referred_user_id: userId,
    p_payment_reference: reference,
    p_amount_kobo: 300000
  });
  if (rewardError) {
    console.error("Referral reward processing failed", rewardError.message);
    return NextResponse.json({ error: "Referral reward processing failed; webhook may be retried." }, { status: 500 });
  }
  return NextResponse.json({ received: true });
}
