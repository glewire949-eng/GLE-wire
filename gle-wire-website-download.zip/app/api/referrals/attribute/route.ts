import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
import { adminSupabase } from "@/lib/server-supabase";

export const runtime = "nodejs";

// Called after signup with a referral code retained from the signup URL.
export async function POST(request: Request) {
  const auth = request.headers.get("authorization") || "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7) : "";
  if (!token) return NextResponse.json({ error: "Log in first." }, { status: 401 });
  const body = await request.json().catch(() => ({}));
  const code = typeof body.code === "string" ? body.code.trim().toUpperCase() : "";
  if (!code || code.length > 40) return NextResponse.json({ error: "Invalid referral code." }, { status: 400 });

  const url = process.env.NEXT_PUBLIC_SUPABASE_URL!;
  const anon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;
  const client = createClient(url, anon, { global: { headers: { Authorization: `Bearer ${token}` } } });
  const { data: { user }, error } = await client.auth.getUser(token);
  if (error || !user) return NextResponse.json({ error: "Invalid session." }, { status: 401 });

  const admin = adminSupabase();
  const { data: referralCode } = await admin.from("referral_codes").select("user_id").eq("code", code).maybeSingle();
  if (!referralCode) return NextResponse.json({ error: "Referral code not found." }, { status: 404 });
  if (referralCode.user_id === user.id) return NextResponse.json({ error: "You cannot refer your own account." }, { status: 400 });

  const { data: already } = await admin.from("referrals").select("id").eq("referred_user_id", user.id).maybeSingle();
  if (already) return NextResponse.json({ attributed: true, message: "Referral already recorded." });

  const { error: insertError } = await admin.from("referrals").insert({ referrer_id: referralCode.user_id, referred_user_id: user.id });
  if (insertError) return NextResponse.json({ error: "Referral could not be recorded." }, { status: 500 });
  return NextResponse.json({ attributed: true });
}
