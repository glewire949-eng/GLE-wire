import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
import { adminSupabase } from "@/lib/server-supabase";
import { randomBytes } from "node:crypto";

export const runtime = "nodejs";

export async function GET(request: Request) {
  const auth = request.headers.get("authorization") || "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7) : "";
  if (!token) return NextResponse.json({ error: "Log in first." }, { status: 401 });

  const url = process.env.NEXT_PUBLIC_SUPABASE_URL!;
  const anon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;
  const client = createClient(url, anon, { global: { headers: { Authorization: `Bearer ${token}` } } });
  const { data: { user }, error } = await client.auth.getUser(token);
  if (error || !user) return NextResponse.json({ error: "Invalid session." }, { status: 401 });

  const admin = adminSupabase();
  const { data: existing } = await admin.from("referral_codes").select("code").eq("user_id", user.id).maybeSingle();
  let code = existing?.code;
  if (!code) {
    code = randomBytes(6).toString("hex").toUpperCase();
    const { error: insertError } = await admin.from("referral_codes").insert({ user_id: user.id, code });
    if (insertError) {
      const { data: raced } = await admin.from("referral_codes").select("code").eq("user_id", user.id).maybeSingle();
      if (!raced) return NextResponse.json({ error: "Could not create referral code." }, { status: 500 });
      code = raced.code;
    }
  }

  const { count: referrals } = await admin.from("referrals").select("*", { count: "exact", head: true }).eq("referrer_id", user.id);
  const { data: rewards } = await admin.from("referral_rewards").select("reward_kobo,status").eq("referrer_id", user.id);
  const earnedKobo = (rewards || []).filter(r => r.status === "approved" || r.status === "paid").reduce((sum, r) => sum + r.reward_kobo, 0);
  const pendingKobo = (rewards || []).filter(r => r.status === "pending").reduce((sum, r) => sum + r.reward_kobo, 0);
  const base = process.env.NEXT_PUBLIC_SITE_URL || new URL(request.url).origin;
  return NextResponse.json({
    code,
    link: `${base}/?ref=${code}`,
    referrals: referrals || 0,
    earnedNaira: earnedKobo / 100,
    pendingNaira: pendingKobo / 100
  });
}
