-- Run this entire file in Supabase Dashboard > SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text unique,
  created_at timestamptz not null default now()
);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = ''
as $$
begin
  insert into public.profiles (id, email)
  values (new.id, lower(new.email))
  on conflict (id) do update set email = excluded.email;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert or update of email on auth.users
for each row execute procedure public.handle_new_user();

create table if not exists public.subscriptions (
  user_id uuid primary key references auth.users(id) on delete cascade,
  status text not null default 'inactive' check (status in ('active','inactive','cancelled')),
  current_period_start timestamptz,
  current_period_end timestamptz,
  last_payment_reference text,
  updated_at timestamptz not null default now()
);

create table if not exists public.payment_events (
  reference text primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  amount_kobo integer not null,
  currency text not null check (currency = 'NGN'),
  status text not null check (status = 'success'),
  created_at timestamptz not null default now()
);

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  is_direct boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.conversation_members (
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  primary key (conversation_id, user_id)
);

create table if not exists public.messages (
  id bigint generated always as identity primary key,
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references auth.users(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 2000),
  created_at timestamptz not null default now()
);

create index if not exists messages_conversation_created_idx on public.messages(conversation_id, created_at);

create or replace function public.has_active_subscription(uid uuid)
returns boolean language sql stable security definer set search_path = ''
as $$
  select exists (
    select 1 from public.subscriptions s
    where s.user_id = uid and s.status = 'active' and s.current_period_end > now()
  );
$$;

create or replace function public.get_or_create_direct_conversation(other_user_id uuid)
returns uuid language plpgsql security definer set search_path = ''
as $$
declare
  me uuid := auth.uid();
  conv_id uuid;
begin
  if me is null or other_user_id is null or me = other_user_id then
    raise exception 'Invalid conversation members';
  end if;
  if not public.has_active_subscription(me) or not public.has_active_subscription(other_user_id) then
    raise exception 'Both users need an active subscription';
  end if;

  select c.id into conv_id
  from public.conversations c
  where c.is_direct = true
    and exists (select 1 from public.conversation_members m where m.conversation_id=c.id and m.user_id=me)
    and exists (select 1 from public.conversation_members m where m.conversation_id=c.id and m.user_id=other_user_id)
    and (select count(*) from public.conversation_members m where m.conversation_id=c.id) = 2
  limit 1;

  if conv_id is null then
    insert into public.conversations default values returning id into conv_id;
    insert into public.conversation_members(conversation_id,user_id) values (conv_id,me),(conv_id,other_user_id);
  end if;
  return conv_id;
end;
$$;

alter table public.profiles enable row level security;
alter table public.subscriptions enable row level security;
alter table public.payment_events enable row level security;
alter table public.conversations enable row level security;
alter table public.conversation_members enable row level security;
alter table public.messages enable row level security;

drop policy if exists "Profiles visible to signed-in users for lookup" on public.profiles;
create policy "Profiles visible to signed-in users for lookup" on public.profiles
for select to authenticated using (auth.uid() is not null);
drop policy if exists "Users update own profile" on public.profiles;
create policy "Users update own profile" on public.profiles
for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

drop policy if exists "Read own subscription" on public.subscriptions;
create policy "Read own subscription" on public.subscriptions for select to authenticated using (auth.uid() = user_id);
drop policy if exists "Read own payment event" on public.payment_events;
create policy "Read own payment event" on public.payment_events for select to authenticated using (auth.uid() = user_id);

drop policy if exists "Members can view their conversations" on public.conversations;
create policy "Members can view their conversations" on public.conversations for select to authenticated
using (exists (select 1 from public.conversation_members m where m.conversation_id=id and m.user_id=auth.uid()));
drop policy if exists "Members can view membership rows" on public.conversation_members;
create policy "Members can view membership rows" on public.conversation_members for select to authenticated
using (exists (select 1 from public.conversation_members mine where mine.conversation_id=conversation_id and mine.user_id=auth.uid()));
drop policy if exists "Subscribed members can read messages" on public.messages;
create policy "Subscribed members can read messages" on public.messages for select to authenticated
using (
  public.has_active_subscription(auth.uid())
  and exists (select 1 from public.conversation_members m where m.conversation_id=messages.conversation_id and m.user_id=auth.uid())
);
drop policy if exists "Subscribed members can send messages" on public.messages;
create policy "Subscribed members can send messages" on public.messages for insert to authenticated
with check (
  sender_id=auth.uid()
  and public.has_active_subscription(auth.uid())
  and exists (select 1 from public.conversation_members m where m.conversation_id=messages.conversation_id and m.user_id=auth.uid())
);

grant execute on function public.get_or_create_direct_conversation(uuid) to authenticated;
grant execute on function public.has_active_subscription(uuid) to authenticated;
grant select on public.profiles, public.subscriptions, public.payment_events, public.conversations, public.conversation_members, public.messages to authenticated;
grant update on public.profiles to authenticated;
grant insert on public.messages to authenticated;

-- NOTE: service role key bypasses RLS and must stay server-only.


-- Referral program: each account has a unique referral code; attribution is stored once.
create table if not exists public.referral_codes (
  user_id uuid primary key references auth.users(id) on delete cascade,
  code text not null unique,
  created_at timestamptz not null default now()
);

create table if not exists public.referrals (
  id bigint generated always as identity primary key,
  referrer_id uuid not null references auth.users(id) on delete cascade,
  referred_user_id uuid not null unique references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  check (referrer_id <> referred_user_id)
);

create table if not exists public.referral_rewards (
  id bigint generated always as identity primary key,
  referrer_id uuid not null references auth.users(id) on delete cascade,
  referred_user_id uuid not null references auth.users(id) on delete cascade,
  payment_reference text not null unique references public.payment_events(reference) on delete cascade,
  reward_kobo integer not null check (reward_kobo >= 0),
  status text not null default 'pending' check (status in ('pending','approved','paid','reversed')),
  created_at timestamptz not null default now()
);

alter table public.referral_codes enable row level security;
alter table public.referrals enable row level security;
alter table public.referral_rewards enable row level security;

drop policy if exists "Users can read own referral code" on public.referral_codes;
create policy "Users can read own referral code" on public.referral_codes
for select to authenticated using (auth.uid() = user_id);

drop policy if exists "Users can read referrals they sent" on public.referrals;
create policy "Users can read referrals they sent" on public.referrals
for select to authenticated using (auth.uid() = referrer_id);

drop policy if exists "Users can read own referral rewards" on public.referral_rewards;
create policy "Users can read own referral rewards" on public.referral_rewards
for select to authenticated using (auth.uid() = referrer_id);

grant select on public.referral_codes, public.referrals, public.referral_rewards to authenticated;

-- Referral codes and attributions should be created by trusted server-side code only.
-- Do not add browser insert/update policies to these tables.


-- =========================
-- G L E WIRE REFERRAL SYSTEM
-- =========================
-- Existing projects: run this updated schema in SQL Editor. It replaces the
-- auth trigger so it creates a unique referral code and captures signup attribution.

alter table public.profiles
  add column if not exists referral_code text,
  add column if not exists referred_by uuid references public.profiles(id);

create unique index if not exists profiles_referral_code_unique
  on public.profiles(referral_code) where referral_code is not null;

create table if not exists public.referral_rewards (
  id uuid primary key default gen_random_uuid(),
  referrer_id uuid not null references auth.users(id) on delete restrict,
  referred_user_id uuid not null unique references auth.users(id) on delete restrict,
  payment_reference text not null unique references public.payment_events(reference) on delete restrict,
  amount_kobo integer not null check (amount_kobo = 30000),
  created_at timestamptz not null default now()
);

create table if not exists public.referral_payout_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete restrict,
  amount_kobo integer not null check (amount_kobo >= 500000),
  status text not null default 'pending' check (status in ('pending','approved','paid','rejected')),
  admin_note text,
  created_at timestamptz not null default now(),
  reviewed_at timestamptz,
  paid_at timestamptz
);

create index if not exists referral_rewards_referrer_idx
  on public.referral_rewards(referrer_id, created_at desc);
create index if not exists referral_payout_user_idx
  on public.referral_payout_requests(user_id, created_at desc);

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  code text;
  referrer uuid;
  submitted_code text;
begin
  submitted_code := upper(trim(coalesce(new.raw_user_meta_data ->> 'referral_code', '')));
  if submitted_code <> '' then
    select p.id into referrer
    from public.profiles p
    where upper(p.referral_code) = submitted_code
      and p.id <> new.id
    limit 1;
  end if;

  code := upper(substr(encode(gen_random_bytes(8), 'hex'), 1, 12));
  insert into public.profiles (id, email, referral_code, referred_by)
  values (new.id, lower(new.email), code, referrer)
  on conflict (id) do update
    set email = excluded.email,
        referred_by = coalesce(public.profiles.referred_by, excluded.referred_by),
        referral_code = coalesce(public.profiles.referral_code, excluded.referral_code);
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert or update of email on auth.users
for each row execute procedure public.handle_new_user();

alter table public.referral_rewards enable row level security;
alter table public.referral_payout_requests enable row level security;

drop policy if exists "Users can read their own referral rewards" on public.referral_rewards;
create policy "Users can read their own referral rewards"
on public.referral_rewards for select to authenticated
using (referrer_id = auth.uid());

drop policy if exists "Users can read their own payout requests" on public.referral_payout_requests;
create policy "Users can read their own payout requests"
on public.referral_payout_requests for select to authenticated
using (user_id = auth.uid());

grant select on public.referral_rewards, public.referral_payout_requests to authenticated;

-- Called only by server-side service-role code after Paystack transaction
-- verification and payment_events insertion. First verified subscription only.
create or replace function public.award_referral_reward(
  p_referred_user_id uuid,
  p_payment_reference text,
  p_amount_kobo integer
)
returns boolean
language plpgsql
security definer
set search_path = ''
as $$
declare
  referrer uuid;
  event_user uuid;
  event_amount integer;
  inserted_count integer;
begin
  if p_amount_kobo <> 300000 then
    return false;
  end if;

  select pe.user_id, pe.amount_kobo into event_user, event_amount
  from public.payment_events pe
  where pe.reference = p_payment_reference
    and pe.status = 'success'
    and pe.currency = 'NGN';

  if event_user is null or event_user <> p_referred_user_id or event_amount <> 300000 then
    return false;
  end if;

  select p.referred_by into referrer
  from public.profiles p
  where p.id = p_referred_user_id;

  if referrer is null or referrer = p_referred_user_id then
    return false;
  end if;

  -- One reward per referred user across their lifetime; unique constraints stop replay.
  insert into public.referral_rewards(referrer_id, referred_user_id, payment_reference, amount_kobo)
  values (referrer, p_referred_user_id, p_payment_reference, 30000)
  on conflict do nothing;

  get diagnostics inserted_count = row_count;
  return inserted_count > 0;
end;
$$;

-- A user can request a withdrawal only if enough unreserved, earned rewards exist.
-- Advisory transaction lock prevents two simultaneous requests overspending the balance.
create or replace function public.request_referral_payout()
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  me uuid := auth.uid();
  earned bigint;
  reserved bigint;
  available bigint;
  request_id uuid;
begin
  if me is null then
    raise exception 'You must be logged in';
  end if;

  perform pg_advisory_xact_lock(hashtextextended(me::text, 0));

  select coalesce(sum(r.amount_kobo), 0) into earned
  from public.referral_rewards r where r.referrer_id = me;

  select coalesce(sum(p.amount_kobo), 0) into reserved
  from public.referral_payout_requests p
  where p.user_id = me and p.status in ('pending','approved','paid');

  available := earned - reserved;
  if available < 500000 then
    raise exception 'Minimum withdrawal is ₦5,000 and your available balance is too low';
  end if;

  -- Request all currently available funds; a later admin may approve/reject.
  insert into public.referral_payout_requests(user_id, amount_kobo, status)
  values (me, available, 'pending')
  returning id into request_id;

  return request_id;
end;
$$;

revoke all on function public.award_referral_reward(uuid, text, integer) from public, anon, authenticated;
grant execute on function public.award_referral_reward(uuid, text, integer) to service_role;
revoke all on function public.request_referral_payout() from public, anon;
grant execute on function public.request_referral_payout() to authenticated;

-- Admin payout handling is intentionally manual at first:
-- review pending rows in the Supabase dashboard, confirm the user's payout details
-- through a secure process, pay externally, then set status='paid' and paid_at=now().
-- Do not expose service_role credentials or let users update payout status.
