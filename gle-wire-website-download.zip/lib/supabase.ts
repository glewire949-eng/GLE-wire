import { createClient } from "@supabase/supabase-js";

export function browserSupabase() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!url || !key) throw new Error("Add Supabase URL and publishable/anon key to .env.local");
  return createClient(url, key);
}
