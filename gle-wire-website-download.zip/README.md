# G L E WIRE starter

A dark-themed Next.js starter for a private family/friends chat membership site:
- public email/password signup and login (Supabase Auth)
- monthly membership price: ₦3,000
- Paystack transaction initialization and server-side verification
- signed Paystack webhook handler
- Supabase tables with Row Level Security (RLS)
- basic direct-message creation
- referral links and referral-attribution tables/API (rewards require server-side approval)

This is a starter, not yet a production-ready commercial chat service. Read the limitations below before accepting real payments.

## Phone-friendly setup

You can do the setup from an Android phone using your browser. A laptop is easier, but not required.

1. Create a free GitHub account at https://github.com if you don't have one.
2. Create a free Supabase project at https://supabase.com. In **SQL Editor**, open `supabase/schema.sql` from this project, copy all of it, paste it into SQL Editor, and press **Run**.
3. In Supabase, open **Project Settings → API**. Copy the Project URL and the publishable/anon key. Keep the service-role key private.
4. Create a Paystack account at https://dashboard.paystack.com. Use the **test secret key** first. A live account may require business/identity verification and is subject to Paystack's terms.
5. Put this project into a GitHub repository. On a phone, you can upload the extracted files through GitHub's website, or use a browser-based development environment.
6. Import the repository into https://vercel.com and deploy it.
7. In Vercel → Project → Settings → Environment Variables, set:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY` (server-only)
   - `PAYSTACK_SECRET_KEY` (start with the `sk_test_...` key; server-only)
   - `NEXT_PUBLIC_SITE_URL` (your deployed HTTPS URL, with no trailing slash)
8. Redeploy after adding environment variables.
9. In Paystack dashboard → Settings/API keys & webhooks, configure the webhook URL:
   `https://YOUR-DEPLOYED-DOMAIN/api/paystack/webhook`
10. In Supabase Auth settings, configure your deployed site URL and allowed redirect URLs.
11. Test sign-up, login, checkout with Paystack test credentials, callback verification, and chat access before changing to live keys.

## Running locally

Requires Node.js 20+ on a computer or a cloud development environment:

```bash
npm install
cp .env.example .env.local
npm run dev
```

Open http://localhost:3000.

## Security notes

- Never put `PAYSTACK_SECRET_KEY` or `SUPABASE_SERVICE_ROLE_KEY` in a `NEXT_PUBLIC_` variable, browser code, screenshots, or public repository.
- Paystack amount is sent in kobo: ₦3,000 = 300,000 kobo.
- The server checks status, exact amount, currency, reference ownership and user metadata before granting membership.
- The webhook checks `x-paystack-signature` using HMAC SHA-512 and verifies the transaction with Paystack.
- Payment event references are unique to prevent the same reference being fulfilled twice.
- Do not accept screenshots or browser redirects as proof of payment.

## Important limitations before production

This starter is a foundation and needs more work before public launch:
- The starter sends the current Supabase access token in the `Authorization` header for checkout initialization and callback verification. Test session expiry and sign-in behavior before launch.
- The starter UI is not a complete inbox: add a conversation list, filter messages by the selected conversation, and use Supabase Realtime for live updates.
- Add abuse reporting/blocking, rate limits, account deletion, privacy policy, terms, refund/cancellation rules and support contact.
- Add automated tests, monitoring, backups, and payment reconciliation.
- Monthly access currently means 30 days after a verified one-time payment. It does not automatically charge again. For auto-renewal, implement Paystack subscriptions and customer authorization carefully; otherwise users must manually renew.
- The simple verify route and webhook should be refactored to share one idempotent database function/transaction before production. Add a durable payment state table before exposing this to customers.
- The SQL grants authenticated users profile email lookup for this minimal demo. Consider a safer user search endpoint that reveals only usernames, not email addresses, before public launch.
- The initial UI shows a recent message feed rather than a fully filtered inbox; do not treat this as production-ready private chat until the inbox is implemented and tested.
- Free tiers have limits and can change. Review each provider's current pricing and acceptable-use terms.

## Official documentation

- Supabase Next.js Auth: https://supabase.com/docs/guides/auth/quickstarts/nextjs
- Paystack accept payments: https://paystack.com/docs/payments/accept-payments/
- Paystack verify payments: https://paystack.com/docs/payments/verify-payments/
- Paystack webhooks: https://paystack.com/docs/payments/webhooks/


## Referral / invite feature

- Users can copy/share their own personal invite link, including WhatsApp share.
- Referral code is attached to the new account through the referral API.
- `referral_rewards` records reward amounts and statuses; only trusted server-side code/admin should approve or pay rewards.
- This starter intentionally does **not** automatically pay commissions or credit a withdrawable wallet yet. Decide a clear commission (for example a fixed ₦ amount or percentage) and add fraud checks, refund/chargeback reversals, withdrawal verification, minimum payout and terms before enabling cash payouts.
- Do not reward clicks or raw shares. Reward only genuine, verified paid subscriptions, and disclose the terms. Do not allow self-referrals or duplicate referral attribution.


## Referral earnings (added)

- Every account receives a unique referral code in `profiles.referral_code`.
- A new user can register with `/?ref=CODE`; the signup form also accepts an optional referral code.
- Attribution is captured by the database trigger, and self-referrals are rejected.
- The referrer earns ₦300 (30,000 kobo) only after the referred user's first verified ₦3,000 (300,000 kobo) subscription payment. Sign-ups alone earn nothing.
- `referral_rewards` is an append-only ledger with unique referred-user and payment-reference constraints to prevent duplicate rewards.
- Cash payout requests have a ₦5,000 minimum and reserve the available balance while pending/approved/paid. Users cannot change their own payout status.
- Payout requests are **admin-reviewed and manually paid** at first. In Supabase, inspect `referral_payout_requests`, approve or reject according to your policy, send the payout using a secure provider, then mark it `paid` and set `paid_at`. Never store bank PINs, passwords or OTPs.
- The reward function is only executable by the server-side `service_role`; payment verification and webhook code call it after verified transaction recording.
- The reward is a business expense funded from actual verified subscription revenue. Keep sufficient cash for Paystack fees, taxes, refunds, hosting and chargebacks before approving payouts.

## Referral system deployment notes

1. Run the updated `supabase/schema.sql` in Supabase SQL Editor. It is designed to add referral columns/tables and replace the auth trigger, but back up important production data first.
2. Redeploy the app after uploading the updated files.
3. Keep the service-role key and Paystack secret key server-side only.
4. Test with Paystack test transactions: referral signup with and without a code, self-referral, duplicate webhook, cancelled/failed payment, duplicate payment reference, and payout requests below/above ₦5,000.
5. Before public launch, add a secure admin interface, identity/payout verification, referral abuse monitoring, a dispute process and written referral/payout terms. Manual payout approval is intentionally not automated.

Important: the starter currently gives one referral reward per referred account lifetime, on its first qualifying verified ₦3,000 payment. If a refund or chargeback occurs, an admin must review and reverse the unpaid reward/hold payout under your published terms. Do not silently promise rewards that the business cannot afford.
